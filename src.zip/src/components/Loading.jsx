import React from "react";

function Loading() {
  return (
    <div
      className="flex h-screen items-center justify-center bg-slate-600"
      aria-live="polite"
    >
      <div className="flex flex-col gap-4 w-52">
        <div className="skeleton h-32 w-full" aria-hidden="true"></div>
        <div className="skeleton h-4 w-28" aria-hidden="true"></div>
        <div className="skeleton h-4 w-full" aria-hidden="true"></div>
        <div className="skeleton h-4 w-full" aria-hidden="true"></div>
      </div>
    </div>
  );
}

export default Loading;
