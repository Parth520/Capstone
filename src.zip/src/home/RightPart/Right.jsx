import React, { useEffect } from "react";
import Chatuser from "./Chatuser";
import Messages from "./Messages";
import Typesend from "./Typesend";
import useConversation from "../../zustand/useConversation.js";
import { useAuth } from "../../context/AuthProvider.jsx";
import { CiMenuFries } from "react-icons/ci";

function Right() {
  const { selectedConversation, setSelectedConversation } = useConversation();

  // Reset selected conversation on component unmount
  useEffect(() => {
    return () => setSelectedConversation(null);
  }, [setSelectedConversation]);

  return (
    <div className="w-full bg-slate-900 text-gray-300">
      {!selectedConversation ? (
        <NoChatSelected />
      ) : (
        <div className="flex flex-col h-screen">
          <Chatuser />
          <div className="flex-1 overflow-y-auto max-h-[calc(92vh-8vh)]">
            <Messages />
          </div>
          <Typesend />
        </div>
      )}
    </div>
  );
}

export default Right;

// NoChatSelected Component
const NoChatSelected = () => {
  const [authUser] = useAuth();

  // Safeguard in case authUser is undefined
  const userFullName = authUser?.user?.fullname || "User";

  return (
    <div className="relative h-screen flex items-center justify-center">
      <label
        htmlFor="my-drawer-2"
        className="btn btn-ghost drawer-button lg:hidden absolute left-5"
      >
        <CiMenuFries className="text-white text-xl" />
      </label>
      <h1 className="text-center">
        Welcome,{" "}
        <span className="font-semibold text-xl">{userFullName}</span>!
        <br />
        No chat selected. Please start a conversation by selecting a contact.
      </h1>
    </div>
  );
};
