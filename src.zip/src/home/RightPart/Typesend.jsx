import React, { useState } from "react";
import { IoSend } from "react-icons/io5";
import useSendMessage from "../../context/useSendMessage.js";

function Typesend() {
  const [message, setMessage] = useState("");
  const { loading, sendMessages } = useSendMessage();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Prevent sending empty or whitespace-only messages
    if (message.trim() === "") return;

    try {
      await sendMessages(message.trim());
      setMessage(""); // Clear the input after successful send
    } catch (error) {
      console.error("Failed to send message:", error); // Handle errors gracefully
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="flex items-center space-x-2 h-[8vh] bg-gray-800 px-4">
        {/* Input Field */}
        <input
          type="text"
          placeholder="Type here"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          disabled={loading} // Disable input while loading
          className={`flex-1 border border-gray-700 rounded-xl outline-none px-4 py-3 text-gray-300 bg-gray-900 ${
            loading ? "opacity-50 cursor-not-allowed" : ""
          }`}
        />

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading} // Disable button while loading
          aria-label="Send message"
          className={`flex items-center justify-center p-3 rounded-full text-gray-300 bg-blue-600 hover:bg-blue-500 transition ${
            loading ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <IoSend className="text-2xl" />
        </button>
      </div>
    </form>
  );
}

export default Typesend;
