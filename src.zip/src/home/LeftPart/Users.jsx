import React from "react";
import User from "./User";
import useGetAllUsers from "../../context/useGetAllUsers";

function Users() {
  const [allUsers, loading] = useGetAllUsers();

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <h1 className="text-white font-semibold">Loading users...</h1>
      </div>
    );
  }

  if (!allUsers || allUsers.length === 0) {
    return (
      <div className="flex justify-center items-center h-full">
        <h1 className="text-white font-semibold">No users found</h1>
      </div>
    );
  }

  return (
    <div>
      <h1 className="px-8 py-2 text-white font-semibold bg-slate-800 rounded-md">
        Messages
      </h1>
      <div className="py-2 flex-1 overflow-y-auto max-h-[calc(84vh-10vh)]">
        {allUsers.map((user) => (
          <User key={user._id} user={user} />
        ))}
      </div>
    </div>
  );
}

export default Users;
