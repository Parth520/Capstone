import React from "react";
import useConversation from "../../zustand/useConversation.js";
import { useSocketContext } from "../../context/SocketContext.jsx";

import profilePlaceholder from "../../assets/user.jpg";

function User({ user }) {
  const { selectedConversation, setSelectedConversation } = useConversation();
  const { socket, onlineUsers } = useSocketContext();

  const isSelected = selectedConversation?._id === user._id;
  const isOnline = onlineUsers.includes(user._id);

  const handleClick = () => {
    setSelectedConversation(user);
  };

  return (
    <div
      className={`hover:bg-slate-600 duration-300 ${
        isSelected ? "bg-slate-700" : ""
      }`}
      onClick={handleClick}
    >
      <div className="flex space-x-4 px-8 py-3 cursor-pointer">
        {/* Avatar with Online Indicator */}
        <div className="relative">
          <div className={`avatar ${isOnline ? "online" : ""}`}>
            <div className="w-12 rounded-full">
              <img
                src={user.profileImage || profilePlaceholder}
                alt={`${user.fullname}'s profile`}
              />
            </div>
          </div>
          {isOnline && (
            <div className="absolute bottom-1 right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-gray-900"></div>
          )}
        </div>

        {/* User Information */}
        <div>
          <h1 className="font-bold text-white">{user.fullname}</h1>
          <span className="text-gray-400 text-sm">{user.email}</span>
        </div>
      </div>
    </div>
  );
}

export default User;
