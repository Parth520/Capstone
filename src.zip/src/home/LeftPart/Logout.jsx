import React, { useState } from "react";
import { BiLogOutCircle } from "react-icons/bi";
import axios from "axios";
import Cookies from "js-cookie";
import toast from "react-hot-toast";

function Logout() {
  const [loading, setLoading] = useState(false);

  const handleLogout = async () => {
    if (loading) return; // Prevent multiple clicks

    setLoading(true);
    try {
      const res = await axios.post("/api/user/logout"); // Handle the response if needed
      // Clean up user session data
      localStorage.removeItem("ChatApp");
      Cookies.remove("jwt");

      toast.success("Logged out successfully");
      setLoading(false);
      
      // Navigate to login or home page
      window.location.href = "/login";
    } catch (error) {
      console.error("Error during logout:", error);
      toast.error(error.response?.data?.message || "Error in logging out");
      setLoading(false);
    }
  };

  return (
    <>
      <hr />
      <div className="h-[10vh] bg-transparent flex items-center justify-start">
        <button
          onClick={handleLogout}
          disabled={loading}
          className={`text-5xl text-white hover:bg-slate-700 duration-300 cursor-pointer rounded-full p-2 ml-2 mt-1 ${
            loading ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <BiLogOutCircle />
        </button>
      </div>
    </>
  );
}

export default Logout;
