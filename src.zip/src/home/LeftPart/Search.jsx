import React, { useState } from "react";
import { FaSearch } from "react-icons/fa";
import useGetAllUsers from "../../context/useGetAllUsers";
import useConversation from "../../zustand/useConversation";
import toast from "react-hot-toast";

function Search() {
  const [search, setSearch] = useState("");
  const [allUsers] = useGetAllUsers();
  const { setSelectedConversation } = useConversation();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!search) return;

    if (!allUsers || allUsers.length === 0) {
      toast.error("No users available for search");
      return;
    }

    const searchLower = search.toLowerCase(); // Precompute for optimization
    const conversation = allUsers.find((user) =>
      user.fullname?.toLowerCase().includes(searchLower)
    );

    if (conversation) {
      setSelectedConversation(conversation);
      setSearch("");
      toast.success(`Found user: ${conversation.fullname}`);
    } else {
      toast.error("User not found");
    }
  };

  return (
    <div className="h-[10vh]">
      <div className="px-6 py-4">
        <form onSubmit={handleSubmit}>
          <div className="flex space-x-3 items-center">
            <label
              htmlFor="search-input"
              className="border-[1px] border-gray-700 bg-slate-900 rounded-lg flex items-center gap-2 w-[80%] p-3"
            >
              <input
                id="search-input"
                type="text"
                className="grow outline-none bg-transparent"
                placeholder="Search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </label>
            <button
              type="submit"
              className="hover:bg-gray-600 rounded-full duration-300 text-5xl p-2"
            >
              <FaSearch />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Search;
