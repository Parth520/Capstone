// useGetAllUsers.jsx
import React, { useEffect, useState } from "react";
import Cookies from "js-cookie";
import axios from "axios";

export function useGetAllUsers() {  // Change default export to named export
  const [allUsers, setAllUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getUsers = async () => {
      setLoading(true);
      setError(null);
      try {
        const token = Cookies.get("jwt");
        const response = await axios.get("/api/user/allusers", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setAllUsers(response.data);
      } catch (error) {
        console.error("Error in useGetAllUsers: ", error);
        setError("Failed to load users. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    getUsers();
  }, []);

  return { allUsers, loading, error };
}
