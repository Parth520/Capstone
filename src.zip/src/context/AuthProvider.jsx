import React, { createContext, useContext, useState, useEffect } from "react";
import Cookies from "js-cookie";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const getUserFromStorage = () => {
    try {
      const jwt = Cookies.get("jwt");
      const localData = localStorage.getItem("ChatApp");
      return localData ? JSON.parse(localData) : jwt ? { token: jwt } : null;
    } catch (error) {
      console.error("Error parsing auth data:", error);
      return null;
    }
  };

  const [authUser, setAuthUser] = useState(getUserFromStorage());

  // Sync authUser to localStorage and cookies when it changes
  useEffect(() => {
    if (authUser) {
      if (authUser.token) {
        Cookies.set("jwt", authUser.token, { expires: 7 }); // Optional: configure expiration
      }
      localStorage.setItem("ChatApp", JSON.stringify(authUser));
    } else {
      Cookies.remove("jwt");
      localStorage.removeItem("ChatApp");
    }
  }, [authUser]);

  return (
    <AuthContext.Provider value={[authUser, setAuthUser]}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to access auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
