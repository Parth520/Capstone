import React, { useEffect } from "react";
import { useSocketContext } from "./SocketContext";
import useConversation from "../zustand/useConversation.js";
import sound from "../assets/notification.mp3";

const useGetSocketMessage = () => {
  const { socket } = useSocketContext();
  const { messages, setMessage } = useConversation();

  useEffect(() => {
    const handleNewMessage = (newMessage) => {
      // Play notification sound when a new message is received
      const notification = new Audio(sound);
      notification.play();

      // Update messages state by appending the new message
      setMessage((prevMessages) => [...prevMessages, newMessage]);
    };

    if (socket) {
      socket.on("newMessage", handleNewMessage);
    }

    // Clean up the socket event listener on component unmount
    return () => {
      if (socket) {
        socket.off("newMessage", handleNewMessage);
      }
    };
  }, [socket, setMessage]); // Only depend on socket and setMessage to avoid unnecessary renders

};

export default useGetSocketMessage;
