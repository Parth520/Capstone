import React, { useEffect, useState } from "react";
import useConversation from "../zustand/useConversation.js";
import axios from "axios";

const useGetMessage = () => {
  const [loading, setLoading] = useState(false);
  const { messages, setMessage, selectedConversation } = useConversation();

  useEffect(() => {
    const getMessages = async () => {
      setLoading(true);
      if (selectedConversation && selectedConversation._id) {
        try {
          const res = await axios.get(
            `/api/message/get/${selectedConversation._id}`
          );
          
          // If messages have changed, update the state
          if (JSON.stringify(res.data) !== JSON.stringify(messages)) {
            setMessage(res.data);
          }
          
          setLoading(false);
        } catch (error) {
          console.error("Error in getting messages", error);
          setLoading(false);
          // Optional: handle error visually (e.g., with a toast notification)
        }
      }
    };

    if (selectedConversation) {
      getMessages();
    }

  }, [selectedConversation, setMessage, messages]);

  return { loading, messages };
};

export default useGetMessage;
