import { create } from "zustand";

const useConversation = create((set) => ({
  selectedConversation: null, // Currently selected conversation
  messages: [], // Array to store messages

  // Action to set the selected conversation
  setSelectedConversation: (selectedConversation) =>
    set(() => ({ selectedConversation })),

  // Action to set or update messages
  setMessages: (newMessages) =>
    set((state) => ({
      messages: Array.isArray(newMessages) ? newMessages : state.messages,
    })),

  // Action to add a single message
  addMessage: (newMessage) =>
    set((state) => ({
      messages: [...state.messages, newMessage],
    })),

  // Action to clear conversation
  clearConversation: () =>
    set(() => ({
      selectedConversation: null,
      messages: [],
    })),
}));

export default useConversation;
